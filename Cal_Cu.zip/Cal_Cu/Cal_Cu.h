#ifndef Cal_Cu_H 
#define Cal_Cu_H 
 
#include <Wire.h> 
#include <LiquidCrystal_I2C.h> 
#include <Keypad.h> 
#include <math.h> 
 
class Cal_Cu { 
public: 
    Cal_Cu(uint8_t lcd_addr, uint8_t lcd_cols, uint8_t lcd_rows, byte rows, byte cols, char keys[][6], byte* rowPins, byte* colPins,  
          byte rows2, byte cols2, char keys2[][4], byte* rowPins2, byte* colPins2, int ledPin); 
    void begin(); 
    void loop(); 
 
private: 
    LiquidCrystal_I2C lcd; 
    Keypad keypad; 
    Keypad keypad2; 
    String input; 
    String expression; 
    float lastAnswer; 
    bool squareRootMode; 
    bool cubeRootMode; 
    int led; 
    int counter; 
 
    float evaluate(String expr); 
    void solveQuadraticEquation(); 
    float getNumberFromUser(); 
    void resetCal_Cuulator(); 
    void processTrigonometricOperation(String func); 
    void processInverseTrigonometricOperation(String func); 
    void processHyperbolicOperation(String func); 
    void processLnOperation(); 
    void processFactorialOperation(); 
    unsigned long factorial(int n); 
}; 
 
#endif