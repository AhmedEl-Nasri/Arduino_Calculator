#include "Cal_Cu.h"

Cal_Cu::Cal_Cu(uint8_t lcd_addr, uint8_t lcd_cols, uint8_t lcd_rows, byte rows, byte cols, char keys[][6], byte* rowPins, byte* colPins, 
             byte rows2, byte cols2, char keys2[][4], byte* rowPins2, byte* colPins2, int ledPin)
    : lcd(lcd_addr, lcd_cols, lcd_rows), keypad(Keypad(makeKeymap(keys), rowPins, colPins, rows, cols)), 
      keypad2(Keypad(makeKeymap(keys2), rowPins2, colPins2, rows2, cols2)), led(ledPin) {
    input = "";
    expression = "";
    lastAnswer = 0;
    squareRootMode = false;
    cubeRootMode = false;
    counter = 0;
}

void Cal_Cu::begin() {
    pinMode(led, OUTPUT);
    lcd.init();
    lcd.backlight();
    byte calc[] = {
  0x1F,
  0x11,
  0x1F,
  0x1F,
  0x11,
  0x11,
  0x1B,
  0x1F
};
byte scurt[] = {
  0x00,
  0x07,
  0x04,
  0x04,
  0x14,
  0x0C,
  0x04,
  0x00
};
byte root3[] = {
  0x03,
  0x1A,
  0x0A,
  0x1A,
  0x0A,
  0x1A,
  0x06,
  0x00
};
  lcd.setCursor(0, 0);
  lcd.print("\tArduino_Cal_Cu");
  lcd.setCursor(16, 1);
  lcd.createChar(1, calc);
  lcd.createChar(2, scurt);
  lcd.createChar(3, root3);
  lcd.write(1);
  delay(200);
  lcd.clear();
  for (int pos = 0; pos - 1 < 16; pos++) {
    lcd.clear();
    lcd.setCursor(0 - pos, 0);
    lcd.print("by El-Nasri &");
    lcd.setCursor(7 + pos, 1);
    lcd.print("Hammed");
    delay(20);
  }
  lcd.clear();
  
}

void Cal_Cu::loop() {
    char key = keypad.getKey();
    char key2 = keypad2.getKey();

    if (key) {
        if (key >= '0' && key <= '9') {
            input += key;
            expression += key;
            lcd.print(key);
        } else if (key == 'C') {
            input = "";
            expression = "";
            lcd.clear();
        } else if (key == 'D') {
            if (expression.length() > 0) {
                expression.remove(expression.length() - 1);
                lcd.clear();
                lcd.print(expression);
            }
        } else if (key == '=') {
            if (squareRootMode || cubeRootMode) {
                expression += ")";
                squareRootMode = false;
                cubeRootMode = false;
            }
            expression += key;
            lcd.setCursor(0, 1);
            float result = evaluate(expression);
            lcd.print(result);
            lastAnswer = result;
            input = "";
            expression = "";
        } else if (key == 'R') {
            lcd.clear();
            lcd.setCursor(0, 0);
            lcd.write(2);
            while (true) {
                char key = keypad.getKey();
                if (key) {
                    if ((key >= '0' && key <= '9') || key == '.') {
                        input += key;
                        lcd.print(key);
                    } else if (key == '=') {
                        float num = input.toFloat();
                        float result = sqrt(num);
                        lcd.clear();
                        lcd.setCursor(0, 0);
                        lcd.write(2);
                        lcd.print(input);
                        lcd.setCursor(0, 1);
                        lcd.print(result);
                        lastAnswer = result;
                        input = "";
                        break;
                    }
                }
            }
        } else if (key == 'W') {
            if (input.length() > 0) {
                expression += '^';
                lcd.print('^');
                input = "";
            }
        } else if (key == 'y') {
            resetCal_Cuulator();
        } else if (key == 's') {
            processTrigonometricOperation("Sin");
        } else if (key == 'c') {
            processTrigonometricOperation("Cos");
        } else if (key == 't') {
            processTrigonometricOperation("Tan");
        } else {
            if (input.length() > 0) {
                expression += key;
                lcd.print(key);
                input = "";
            }
        }
    }

    if (key2) {
        if (key2 == 'A') {
            input = String(lastAnswer);
            expression += input;
            lcd.clear();
            lcd.print(input);
            counter++;
            if (counter == 3) {
                digitalWrite(led, 1);
                delay(500);
                digitalWrite(led, 0);
                counter = 0;
            }
        } else if (key2 == 'r') {
            lcd.clear();
            lcd.setCursor(0, 0);
            lcd.write(3);
            while (true) {
                char key = keypad.getKey();
                if (key) {
                    if ((key >= '0' && key <= '9') || key == '.') {
                        input += key;
                        lcd.print(key);
                    } else if (key == '=') {
                        float num = input.toFloat();
                        float result = cbrt(num);
                        lcd.clear();
                        lcd.setCursor(0, 0);
                        lcd.write(3);
                        lcd.print(input);
                        lcd.setCursor(0, 1);
                        lcd.print(result);
                        lastAnswer = result;
                        input = "";
                        expression = "";
                        break;
                    }
                }
            }
        } else if (key2 == 'M') {
            if (input.length() > 0) {
                expression += '%';
                lcd.print('%');
                input = "";
            }
        } else if (key2 == 'L') {
            processLnOperation();
        } else if (key2 == ')') {
            lcd.print(")");
        } else if (key2 == 'E') {
            solveQuadraticEquation();
        } else if (key2 == 'k') {
            processInverseTrigonometricOperation("Sec");
        } else if (key2 == 'n') {
            processInverseTrigonometricOperation("Csc");
        } else if (key2 == 'g') {
            processInverseTrigonometricOperation("Cot");
        } else if (key2 == 'h') {
            processHyperbolicOperation("Sinh");
        } else if (key2 == 'j') {
            processHyperbolicOperation("Cosh");
        } else if (key2 == 'o') {
            processHyperbolicOperation("Tanh");
        } else if (key2 == 'q') {
            processFactorialOperation();
        } else if (key2 == 'p') {
            expression += "3.14";
            lcd.print("3.14");
        } else if (key2 == 'e') {
            expression += "2.718";
            lcd.print("2.718");
        } else if (key2 == '.') {
            expression += ".";
            lcd.print(".");
        }
    }
    delay(20);
}

float Cal_Cu::evaluate(String expr) {
    float result = 0;
  char lastOpp = '+'; // Last operator (+ or -)
  String number = "";
  float tempResult = 0; // Result for multiplication, division, and power
  char tempOpp = '+'; // Operator for multiplication, division, and power

  for (int i = 0; i < expr.length(); i++) {
    char c = expr.charAt(i);

    if (c >= '0' && c <= '9' || c == '.') {
      number += c; // Build the number string
    } else if (c == '*' || c == '/' || c == '^' || c == '%') {
      if (number.length() > 0) {
        float num = number.toFloat();
        switch (tempOpp) {
          case '+': tempResult += num; break;
          case '-': tempResult -= num; break;
          case '*': tempResult *= num; break;
          case '/': tempResult /= num; break;
          case '^': tempResult = pow(tempResult, num); break; // Handle power
          case '%': tempResult = fmod(tempResult, num); break; // Handle modulus
        }
        tempOpp = c;
        number = "";
      }
    } else if (c == '+' || c == '-' || c == '=') {
      if (number.length() > 0) {
        float num = number.toFloat();
        switch (tempOpp) {
          case '+': tempResult += num; break;
          case '-': tempResult -= num; break;
          case '*': tempResult *= num; break;
          case '/': tempResult /= num; break;
          case '^': tempResult = pow(tempResult, num); break; // Handle power
          case '%': tempResult = fmod(tempResult, num); break; // Handle modulus
        }
        switch (lastOpp) {
          case '+': result += tempResult; break;
          case '-': result -= tempResult; break;
        }
        lastOpp = c;
        tempOpp = '+';
        tempResult = 0;
        number = "";
      }
    }
  }

  if (number.length() > 0) {
    float num = number.toFloat();
    switch (tempOpp) {
      case '+': tempResult += num; break;
      case '-': tempResult -= num; break;
      case '*': tempResult *= num; break;
      case '/': tempResult /= num; break;
      case '^': tempResult = pow(tempResult, num); break; // Handle power
      case '%': tempResult = fmod(tempResult, num); break; // Handle modulus
    }
    switch (lastOpp) {
      case '+': result += tempResult; break;
      case '-': result -= tempResult; break;
    }
  }

  return result;
}

void Cal_Cu::solveQuadraticEquation() {
     lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("a, b, c:");
  
  // Prompt user for 'a'
  lcd.setCursor(0, 1);
  lcd.print("a = ");
  float a = getNumberFromUser();
  
  // Prompt user for 'b'
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("b = ");
  float b = getNumberFromUser();
  
  // Prompt user for 'c'
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("c = ");
  float c = getNumberFromUser();
  
  // Cal_Cuulate discriminant
  float discriminant = b * b - 4 * a * c;
  
  // Cal_Cuulate roots
  float root1, root2;
  if (discriminant > 0) {
    root1 = (-b + sqrt(discriminant)) / (2 * a);
    root2 = (-b - sqrt(discriminant)) / (2 * a);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Root1: ");
    lcd.print(root1);
    lcd.setCursor(0, 1);
    lcd.print("Root2: ");
    lcd.print(root2);
  } else if (discriminant == 0) {
    root1 = -b / (2 * a);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Root1: ");
    lcd.print(root1);
  } else {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("No Real Roots");
  }
}

float Cal_Cu::getNumberFromUser() {
    String numberString = "";
  bool negative = false; // Flag to track if the number is negative
  lcd.setCursor(0, 1);
  lcd.print("Input: ");
  
  while (true) {
    char key = keypad.getKey();
    if (key) {
      if (key >= '0' && key <= '9' || key == '.') {
        numberString += key;
        lcd.setCursor(7, 1); // Move cursor to display input
        lcd.print(numberString);
      } else if (key == '-') {
        if (numberString.length() == 0) {
          negative = !negative; // Toggle the negative flag
          lcd.setCursor(7, 1);
          lcd.print(negative ? "-" : " "); // Display or remove the minus sign
        }
      }  
       else if (key == '=') {
        lcd.clear();
        return (negative ? -numberString.toFloat() : numberString.toFloat());
      } else if (key == 'C') { // Clear function
        lcd.clear();
        numberString = "";
        lcd.setCursor(0, 0);
        lcd.print("Input Cleared");
        delay(250);
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("a = ");
        lcd.setCursor(0, 1);
        lcd.print("input = ");
      }
    }
  }
}

void Cal_Cu::resetCal_Cuulator() {
    // Reset Cal_Cuulator state
  input = "";
  expression = "";
  lastAnswer = 0;
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Cal_Cuulator Reset");
  delay(250); // Show the reset message for a short while
  lcd.clear();
}

void Cal_Cu::processTrigonometricOperation(String func) {
   lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(func);
  
  // Wait for user to input the angle and press '='
  while (true) {
    char key = keypad.getKey();
    char key2 = keypad2.getKey();
    if (key) {
      if (key >= '0' && key <= '9') {
        input += key;
        lcd.setCursor(4, 0);
        lcd.print(input);
      } else if (key == '=') {
        float angle = input.toFloat();
        // Convert degrees to radians
        float radian = radians(angle);
        float result = 0;
        if (func == "Sin") {
          result = sin(radian);
        } else if (func == "Cos") {
          result = cos(radian);
        } else if (func == "Tan") {
          result = tan(radian);
        }
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print(func);
        lcd.print(input);
        lcd.setCursor(0, 1);
        lcd.print(result);
        lastAnswer = result; // Store the last answer
        input = "";
        break;
      }
    }
     if (key2) {
      if (key2 == 'e' || key2 == 'p' || key2=='.' ) {
       if (key2 == 'p') { // π function
      input += "180";
      
    } else if (key2 == 'e') { // Euler number (e)
      input += "2.718";
      
    }
    else if (key2 == '.') { // dot
      input += ".";
      
    }
        
        lcd.setCursor(4, 0);
        lcd.print(input);
      } else if (key2 == '=') {
        float angle = input.toFloat();
        // Convert degrees to radians
        float radian = radians(angle);
        float result = 0;
        if (func == "Sin") {
          result = sin(radian);
        } else if (func == "Cos") {
          result = cos(radian);
        } else if (func == "Tan") {
          result = tan(radian);
        }
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print(func);
        lcd.print(input);
        lcd.setCursor(0, 1);
        lcd.print(result);
        lastAnswer = result; // Store the last answer
        input = "";
        break;
      }
    }
  }
}
void Cal_Cu::processInverseTrigonometricOperation(String func) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(func);
  
    // Wait for user to input the angle and press '='
    while (true) {
        char key = keypad.getKey();
        char key2 = keypad2.getKey();
        if (key) {
            if (key >= '0' && key <= '9') {
                input += key;
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key == '=') {
                float angle = input.toFloat();
                // Convert degrees to radians
                float radian = radians(angle);
                float result = 0;
                if (func == "Sec") {
                    result = 1 / cos(radian);
                } else if (func == "Csc") {
                    result = 1 / sin(radian);
                } else if (func == "Cot") {
                    result = 1 / tan(radian);
                }
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(func);
                lcd.print(input);
                lcd.setCursor(0, 1);
                lcd.print(result);
                lastAnswer = result; // Store the last answer
                input = "";
                break;
            }
        }
        if (key2) {
            if (key2 == 'e' || key2 == 'p' || key2 == '.') {
                if (key2 == 'p') { // π function
                    input += "180";
                } else if (key2 == 'e') { // Euler number (e)
                    input += "2.718";
                } else if (key2 == '.') { // Decimal point
                    input += ".";
                }
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key2 == '=') {
                float angle = input.toFloat();
                // Convert degrees to radians
                float radian = radians(angle);
                float result = 0;
                if (func == "Sec") {
                    result = 1 / cos(radian);
                } else if (func == "Csc") {
                    result = 1 / sin(radian);
                } else if (func == "Cot") {
                    result = 1 / tan(radian);
                }
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(func);
                lcd.print(input);
                lcd.setCursor(0, 1);
                lcd.print(result);
                lastAnswer = result; // Store the last answer
                input = "";
                break;
            }
        }
    }
}

void Cal_Cu::processHyperbolicOperation(String func) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(func);

    // Wait for user to input the value and press '='
    while (true) {
        char key = keypad.getKey();
        char key2 = keypad2.getKey();
        if (key) {
            if (key >= '0' && key <= '9') {
                input += key;
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key == '=') {
                float value = input.toFloat();
                float result = 0;
                if (func == "Sinh") {
                    result = sinh(value);
                } else if (func == "Cosh") {
                    result = cosh(value);
                } else if (func == "Tanh") {
                    result = tanh(value);
                }
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(func);
                lcd.print(input);
                lcd.setCursor(0, 1);
                lcd.print(result);
                lastAnswer = result; // Store the last answer
                input = "";
                break;
            }
        }
        if (key2) {
            if (key2 == 'e' || key2 == 'p' || key2 == '.') {
                if (key2 == 'p') { // π function
                    input += "180";
                } else if (key2 == 'e') { // Euler number (e)
                    input += "2.718";
                } else if (key2 == '.') { // Decimal point
                    input += ".";
                }
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key2 == '=') {
                float value = input.toFloat();
                float result = 0;
                if (func == "Sinh") {
                    result = sinh(value);
                } else if (func == "Cosh") {
                    result = cosh(value);
                } else if (func == "Tanh") {
                    result = tanh(value);
                }
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(func);
                lcd.print(input);
                lcd.setCursor(0, 1);
                lcd.print(result);
                lastAnswer = result; // Store the last answer
                input = "";
                break;
            }
        }
    }
}

void Cal_Cu::processLnOperation() {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Ln");

    // Wait for user to input the number and press '='
    while (true) {
        char key = keypad.getKey();
        char key2 = keypad2.getKey();
        if (key) {
            if (key >= '0' && key <= '9') {
                input += key;
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key == '=') {
                float num = input.toFloat();
                if (num > 0) { // Logarithm is only defined for positive numbers
                    float result = log(num); // Cal_Cuulate natural logarithm
                    lcd.clear();
                    lcd.setCursor(0, 0);
                    lcd.print("Ln");
                    lcd.print(input);
                    lcd.setCursor(0, 1);
                    lcd.print(result);
                    lastAnswer = result; // Store the last answer
                } else {
                    lcd.clear();
                    lcd.setCursor(0, 0);
                    lcd.print("Error");
                    lcd.setCursor(0, 1);
                    lcd.print("Invalid Input");
                }
                input = "";
                break;
            }
        }
        if (key2) {
            if (key2 == 'e' || key2 == 'p' || key2 == '.') {
                if (key2 == 'p') { // π function
                    input += "3.14";
                } else if (key2 == 'e') { // Euler number (e)
                    input += "2.718";
                } else if (key2 == '.') { // Decimal point
                    input += ".";
                }
                lcd.setCursor(4, 0);
                lcd.print(input);
            } else if (key2 == '=') {
                float num = input.toFloat();
                if (num > 0) { // Logarithm is only defined for positive numbers
                    float result = log(num); // Cal_Cuulate natural logarithm
                    lcd.clear();
                    lcd.setCursor(0, 0);
                    lcd.print("Ln");
                    lcd.print(input);
                    lcd.setCursor(0, 1);
                    lcd.print(result);
                    lastAnswer = result; // Store the last answer
                } else {
                    lcd.clear();
                    lcd.setCursor(0, 0);
                    lcd.print("Error");
                    lcd.setCursor(0, 1);
                    lcd.print("Invalid Input");
                }
                input = "";
                break;
            }
        }
    }
}

void Cal_Cu::processFactorialOperation() {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(input);
    lcd.print("!");
  
    // Wait for user to input the number and press '='
    while (true) {
        char key = keypad.getKey();
        if (key) {
            if (key >= '0' && key <= '9') {
                input += key;
                lcd.setCursor(3, 0);
                lcd.print(input);
            } else if (key == '=') {
                int number = input.toInt();
                unsigned long result = factorial(number);
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(input + "!");
                lcd.setCursor(0, 1);
                lcd.print(result);
                lastAnswer = result; // Store the last answer
                input = "";
                break;
            }
        }
    }
}

unsigned long Cal_Cu::factorial(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}
